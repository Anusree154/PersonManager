package in.upcode.demojsonxml.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import in.upcode.demojsonxml.model.Person;

public interface PersonRepository extends JpaRepository<Person,Integer> {

}

