package in.upcode.demojsonxml.controller;
import in.upcode.demojsonxml.model.Person;
import in.upcode.demojsonxml.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/api/person")

public class personController {

    @Autowired
    PersonRepository personRepository1;



    @RequestMapping(value ="/json",produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    List<Person> showOnePerson() {


        return personRepository1.findAll();

    }
}

